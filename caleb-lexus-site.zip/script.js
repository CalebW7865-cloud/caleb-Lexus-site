// Tabs + quick actions
const tabs = document.querySelectorAll('.tab');
const panels = document.querySelectorAll('.panel');
tabs.forEach(btn=>btn.addEventListener('click', ()=>{
  tabs.forEach(b=>b.classList.remove('active'));
  panels.forEach(p=>p.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById(btn.dataset.tab).classList.add('active');
}));

// Year
document.getElementById('year') && (document.getElementById('year').textContent = new Date().getFullYear());

// Optional links (replace if you have real links)
const bookingURL = '#';   // e.g., https://calendly.com/yourname/lexus
const reviewURL  = '#';   // e.g., your Google Reviews link
const b = document.getElementById('booking'); if (b) b.href = bookingURL;
const r = document.getElementById('reviews'); if (r) r.href = reviewURL;

// Quick Hold form -> opens SMS with prefilled body
const qh = document.getElementById('quickHold');
if (qh) {
  qh.addEventListener('submit', (e)=>{
    e.preventDefault();
    const model = document.getElementById('modelSel').value;
    const name  = document.getElementById('yourName').value.trim();
    const budget= document.getElementById('budget').value.trim();
    const body = encodeURIComponent(`${model} Hold Request — Name: ${name} | Budget: ${budget}`);
    const link = `sms:+19207189699?&body=${body}`;
    window.location.href = link;
  });
}
